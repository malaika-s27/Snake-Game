package org.cis120.snake;

public interface Food {
    void powerUp(Snake snake);
}
